create function searchTech1(v_id in teacher.t_id%type,v_GENDER out teacher.t_gender%type,v_RESEARCH out teacher.t_research%type)
return teacher.t_name%type
is
  v_name teacher.t_name%type;
begin
  select t.t_name,t.t_gender,t.t_research into v_name,v_GENDER,v_RESEARCH from teacher t where t.t_id=v_id;
  return v_name;
end;
/

