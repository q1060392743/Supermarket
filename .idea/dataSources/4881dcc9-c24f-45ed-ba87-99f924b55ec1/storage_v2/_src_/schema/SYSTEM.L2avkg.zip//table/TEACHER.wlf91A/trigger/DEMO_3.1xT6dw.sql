create trigger DEMO_3
  before insert or update or delete
  on TEACHER
  begin
  if to_char(sysdate,'DY')='星期一' then
    RAISE_APPLICATION_ERROR(-20600,'星期一不能对Teacher表进行修改');
  end if;
end;
/

