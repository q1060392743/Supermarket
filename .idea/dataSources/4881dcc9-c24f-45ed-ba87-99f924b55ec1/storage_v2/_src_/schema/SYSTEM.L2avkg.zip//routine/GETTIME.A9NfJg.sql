create procedure getTime(tentertime out date)
is
begin
   select min(t_entertime) into tentertime from teacher;
end;
/

