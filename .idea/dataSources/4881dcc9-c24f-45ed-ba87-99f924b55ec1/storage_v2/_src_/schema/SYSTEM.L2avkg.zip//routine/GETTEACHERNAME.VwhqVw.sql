create procedure getTeacherName(tid in char, tname out varchar2)
as
begin
  select t_name into tname from teacher where t_id = tid;
  dbms_output.put_line(tname);
end getTeacherName;
/

