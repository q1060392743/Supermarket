create function getStuName (v_id in varchar2)
return varchar2 as
  v_name varchar2(100);
begin
    select s.s_name into v_name from student s where s.s_id=v_id;
    return v_name;
end;
/

