create procedure updateTitle(tid in char)
as
begin
  update teacher t set t.t_titleid = t.t_titleid +1 where t.t_id = tid;
  commit;
end updateTitle;
/

