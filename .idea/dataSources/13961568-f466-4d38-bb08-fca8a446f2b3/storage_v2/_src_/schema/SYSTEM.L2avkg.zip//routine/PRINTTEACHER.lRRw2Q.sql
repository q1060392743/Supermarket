create procedure printTeacher(tid in char, tname out varchar2, tresearch out varchar2)
as
begin
  select t.t_name, t.t_research into tname, tresearch from teacher t where t.t_id = tid;
  dbms_output.put_line(tname||tresearch);
end printTeacher;
/

