create procedure getScore(score in out number)
is
begin
  score := score * 0.7;
end getScore;
/

